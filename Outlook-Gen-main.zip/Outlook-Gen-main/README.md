# Outlook Gen
Outlook Generator using [capsolver.com]

> get your captcha key at: 
> put proxies in `./data/proxies.txt`  
> run with : `python main.py`